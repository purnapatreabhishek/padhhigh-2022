<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "padhhigh";

//details for infuzex database 
// $servername = "localhost";
// $username = "infuzexi_infuzexhosting";
// $password = "Infuzex@123";
// $dbname = "infuzexi_infuzexhosting";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

?>